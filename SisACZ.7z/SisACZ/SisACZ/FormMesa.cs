﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Net;
using System.IO;
using System.Data.SqlClient;
using System.Data;

namespace SisACZ
{
    public partial class FormMesa : Form
    {
        public FormMesa()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                Mesa mesa = new Mesa();
                mesa.Inserir(txtMesa.Text);
                MessageBox.Show("Mesa cadastrada com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Mesa> mes = mesa.listamesa();
                dgvMesa.DataSource = mes;
                txtId.Text = "";
                txtMesa.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                Mesa cliente = new Mesa();
                cliente.Atualizar(txtMesa.Text);
                MessageBox.Show("Mesa atualizada com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Mesa> mes = cliente.listamesa();
                dgvMesa.DataSource = mes;
                txtMesa.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(txtId.Text);
                string cpf = txtMesa.Text.Trim();
                Mesa mesa = new Mesa();
                mesa.Exclui(id);
                MessageBox.Show("Mesa excluída com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Mesa> cli = mesa.listamesa();
                dgvMesa.DataSource = cli;
                txtMesa.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLimpaCampos_Click(object sender, EventArgs e)
        {
            txtId.Text = "";
            txtMesa.Text = "";
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Int32.Parse(txtId.Text);
                Mesa mesa = new Mesa();
                mesa.Exclui(id);
                MessageBox.Show("Produto excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Mesa> pro = mesa.listamesa();
                dgvMesa.DataSource = pro;
                txtId.Text = "";
                txtMesa.Text = "";;
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void FormMesa_Load(object sender, EventArgs e)
        {
            Mesa mes = new Mesa();
            List<Mesa> mesas = mes.listamesa();
            dgvMesa.DataSource = mesas;
        }

        private void dgvMesa_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = this.dgvMesa.Rows[e.RowIndex];
            txtId.Text = row.Cells[0].Value.ToString();
            txtMesa.Text = row.Cells[1].Value.ToString();
        }
    }
}
