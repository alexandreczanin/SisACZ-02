﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SisACZ
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void usúarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormUsuario usu = new FormUsuario();
            usu.Show();
        }

        private void produtoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormProduto pro = new FormProduto();
            pro.Show();
        }

        private void mesaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormMesa mes = new FormMesa();
            mes.Show();
        }
    }
}
